from django.contrib import admin

from .models import Department

admin.site.register(Department)